import urllib.parse
import boto3
import json

def lambda_handler(event, context):
    client = boto3.client('glue')
    # Variables for the job: 
    glueJobName = "AvroFromS3ToHudi"
    s3_bucket_name = event['Records'][0]['s3']['bucket']['name']
    s3_object_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    s3_full_path = "s3://" + s3_bucket_name + "/" + s3_object_key
    print(s3_full_path)
    client.start_job_run(JobName = glueJobName, Arguments = {'--s3_object': s3_full_path})
    return {
        'statusCode': 200,
        'body': json.dumps(f'Glue job "{glueJobName}" triggered')
    }
