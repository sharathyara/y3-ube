import urllib.parse
import boto3
from avro.datafile import DataFileReader, DataFileWriter
from avro.io import DatumReader, DatumWriter
import avro.schema
import json
import os
import io

s3c = boto3.client('s3')
s3r = boto3.resource(service_name='s3', region_name='eu-central-1')
insert_prefix = "users-insert/eu-central-1/stage-yara-digitalsolution-fafm-farm-users-ins/"
update_prefix = "users-update/eu-central-1/stage-yara-digitalsolution-fafm-farm-users-upd/"
keys_to_preserve = ["id", "created_at","updated_at", "deleted_at"]

def cleanup_string(record):
    return str(record).replace(": None", ': null').replace("{'", '{"').replace("'}", '"}').replace("':", '":').replace(": '", ': "').replace("',", '",').replace(", '", ', "')

def get_ids_in_avro(avro_obj):
    deletable_records = []
    for record in avro_obj:
        recordStr = cleanup_string(record)
        json_data = json.loads(recordStr)
        deletable_records.append(json_data["data"]["id"])
    return deletable_records
    
def check_ids_and_replace(avro_obj, check_list, bucket_name, s3_key):
    has_match = False
    idx = 0
    json_data = [] 
    for record in avro_obj:
        recordStr = cleanup_string(record)
        json_data.append(json.loads(recordStr))
        id = json_data[idx]["data"]["id"]
        if id in check_list:
            has_match = True
            for key in list(json_data[idx]["data"].keys()):
                if key not in keys_to_preserve:
                   json_data[idx]["data"][key] = "" 
            json_data[idx]["eventType"] += "-Deleted" 
        else:
            pass
        idx += 1
    if has_match:
        schema = avro.schema.parse(avro_obj.meta["avro.schema"])
        file_name = s3_key.split("/")[-1]
        writer = DataFileWriter(open(f"/tmp/{file_name}", "wb"), DatumWriter(), schema)
        for i in range(idx):
            # print(json_data[i])
            writer.append(json_data[i])
        writer.close()
        s3_key = s3_key.replace(".avro", "_.avro")
        print(f'Object "{s3_key}" has been updated')
        s3r.Bucket(bucket_name).upload_file(f"/tmp/{file_name}", s3_key) 
        os.remove(f"/tmp/{file_name}")

def lambda_handler(event, context):
    # print("Received event: " + json.dumps(event, indent=2))
    # Get the object from the event and show its content type
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    print(f'Processing delete object: "{key}"')
    try:
        response = s3c.get_object(Bucket=bucket, Key=key)
        body = response['Body']
        file_like_obj = io.BytesIO(body.read())
        avro_object = DataFileReader(file_like_obj, DatumReader())
        list_ids = get_ids_in_avro(avro_object)
        print(f"IDs to delete: {list_ids}")
        avro_object.close()
        list_for_insert = list(s3r.Bucket(bucket).objects.filter(Prefix=insert_prefix))
        list_for_update = list(s3r.Bucket(bucket).objects.filter(Prefix=update_prefix))
        list_for_upsert = list_for_insert + list_for_update
        for obj in list_for_upsert:
            # print(obj.key)
            upsert_response = s3c.get_object(Bucket=bucket, Key=obj.key)
            upsert_body = upsert_response['Body']
            upsert_file_like_obj = io.BytesIO(upsert_body.read())
            upsert_avro_object = DataFileReader(upsert_file_like_obj, DatumReader())
            check_ids_and_replace(upsert_avro_object, list_ids, bucket_name=bucket, s3_key=obj.key)
        upsert_avro_object.close()
        # print("CONTENT TYPE: " + response['ContentType'])
        # return response['ContentType']
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
